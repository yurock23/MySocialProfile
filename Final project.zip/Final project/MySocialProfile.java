
import java.io.*;
import java.util.Scanner;
public class MySocialProfile{
    
    public void mainMenu(){
        


    }
    
    
    
    public static void main(args String[]){
        Scanner lineScanner = new Scanner(newFileInputStream("MySocialProfile.txt"));
        
    }

}