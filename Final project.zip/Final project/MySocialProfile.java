import java.io.*;
import java.util.Scanner;

import jdk.internal.org.jline.utils.InputStreamReader;
public class MySocialProfile{
    
    private String name;
    private String email;
    private String password;
    private int classyear;
    private String[] events;
    private String[] timeline;
    private String[] friends;
    
    public MySocialProfile(String name, String email, String password, int classyear, Event events, String timeline, String friends){
        BufferedReader ob = new BufferedReader(new InputStreamReader(System.in()));
        

    }
    
    public void addProfile(){
        MySocialProfile one = new MySocialProfile(name, email, password, year, event, timeline, friend);

    }
    
    public void loadProfile(){

    }

    public void addEvents(){

    }

    public void addTimeline(){

    }

    public void addFriend(){


    }

    public void removeFriend(){

    }

    public void quit(){

        
    }
    public static void main(args String[]){
        Scanner lineScanner = new Scanner(newFileInputStream("MySocialProfile.txt"));
        
    }

}