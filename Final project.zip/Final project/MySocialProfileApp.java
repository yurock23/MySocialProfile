public class MySocialProfileApp{

    public static void main(args[] String){
    int choice, value;
    
    do
    {
        System.out.print("\nEnter a letter: \n\n quit program (q) \n add Profile (a) \n ");
        System.out.print("load Profile (l) \n\t\t --> ");
        choice = getChar();
        
        switch(choice)
        {
            case 'a':
                System.out.print("\nEnter your full name: ");
                System.out.print("\nEnter your email address");
                System.out.print("\nEnter your password");
                System.out.print("\nEnter your class year");
                System.out.print("")
                
                break;
            case 'e':
                addEvent();
            case 'l':
                System.out.println("");
                break;
            case 'q':
                System.out.println("\nGoodbye.");
                break;
            default:
                System.out.print("\nNot a valid entry.\n");
        }  // end switch
        while(choice != q);
    }   
}