import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Event{

    public Event(String event){
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
		event = br.readLine();
    }



    12 3 2020 14 00

    8 23 2020 5 00 




}